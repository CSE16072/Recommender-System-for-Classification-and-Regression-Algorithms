import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from joblib import dump

# Step 1: Load and prepare dataset information
df = pd.read_csv('dataset_info.csv')

# Step 2: Prepare dataset for training
X = df[['num_samples', 'num_features', 'num_classes']]
y = df['recommended_algorithm']

# Step 3: Encode target labels
le = LabelEncoder()
y_encoded = le.fit_transform(y)

# Step 4: Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

# Step 5: Train a Decision Tree classifier
model = DecisionTreeClassifier()
model.fit(X_train, y_train)

# Step 6: Save the trained model and label encoder
dump(model, 'saved_models/recommender_model.joblib')
dump(le, 'saved_models/label_encoder.joblib')

print("Model training and saving completed successfully.")
