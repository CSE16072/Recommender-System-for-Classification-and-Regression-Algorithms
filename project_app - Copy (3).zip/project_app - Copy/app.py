from flask import Flask, request, render_template, redirect, url_for
import pandas as pd
import os
from werkzeug.utils import secure_filename
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.svm import SVC, SVR
from sklearn.neighbors import KNeighborsClassifier, KNeighborsRegressor
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.metrics import accuracy_score, mean_squared_error
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64

app = Flask(__name__)

# Path to the datasets directory
DATASETS_DIR = 'datasets'

# Ensure the datasets directory exists
os.makedirs(DATASETS_DIR, exist_ok=True)

# Load datasets dictionary with filenames and display names
datasets_dict = {
    'breast_cancer.csv': 'Breast Cancer Dataset',
    'heart.csv': 'Heart Dataset',
    'iris.csv': 'Iris Dataset',
    'WineQT.csv': 'WineQT Dataset',
    'pima_indians_diabetes.csv': 'Pima Indians Diabetes Dataset',
    'glass.csv': 'Glass Dataset',
    'Titanic.csv': 'Titanic Dataset'
}

@app.route('/')
def index():
    datasets = [(filename, display_name) for filename, display_name in datasets_dict.items()]
    return render_template('index.html', datasets=datasets)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = secure_filename(file.filename)
            file_path = os.path.join(DATASETS_DIR, filename)
            file.save(file_path)
            return redirect(url_for('process_file', filename=filename))
    return render_template('upload.html')

@app.route('/process/<filename>')
def process_file(filename):
    try:
        file_path = os.path.join(DATASETS_DIR, filename)
        # Read the uploaded file into a DataFrame
        df = pd.read_csv(file_path)

        if df.empty:
            return 'Uploaded file is empty'

        # Assuming the last column is the target
        target_column = df.columns[-1]
        X = df.drop(target_column, axis=1)
        y = df[target_column]

        # Convert columns to numeric where possible
        X = X.apply(pd.to_numeric, errors='ignore')

        # Handle missing values in features and target
        X = X.apply(lambda col: col.fillna(col.mode()[0]) if col.dtype == 'object' else col.fillna(col.median()))
        y = y.fillna(y.mode()[0] if y.dtype == 'object' else y.median())

        # Check if the target variable is categorical or continuous
        if y.dtype == 'object' or y.dtype.name == 'category':
            problem_type = 'classification'
            # Label encode the target variable if it is categorical
            label_encoder = LabelEncoder()
            y = label_encoder.fit_transform(y)
        else:
            problem_type = 'regression'

        # Preprocessor for handling categorical and numeric features
        categorical_features = X.select_dtypes(include=['object']).columns
        numeric_features = X.select_dtypes(include=['number']).columns

        preprocessor = ColumnTransformer(
            transformers=[
                ('num', Pipeline(steps=[
                    ('imputer', SimpleImputer(strategy='median')),
                    ('scaler', StandardScaler())
                ]), numeric_features),
                ('cat', Pipeline(steps=[
                    ('imputer', SimpleImputer(strategy='most_frequent')),
                    ('onehot', OneHotEncoder(handle_unknown='ignore'))
                ]), categorical_features)
            ])

        if problem_type == 'classification':
            models = {
                'Random Forest': RandomForestClassifier(),
                'Logistic Regression': LogisticRegression(max_iter=1000),
                'Support Vector Machine': SVC(),
                'K-Nearest Neighbors': KNeighborsClassifier(),
                'Gradient Boosting': GradientBoostingClassifier(),
                'Naive Bayes': GaussianNB(),
                'Decision Tree': DecisionTreeClassifier()
            }
            # Train models and calculate accuracy
            accuracies = {}
            for model_name, model in models.items():
                pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('classifier', model)])
                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

                pipeline.fit(X_train, y_train)
                y_pred = pipeline.predict(X_test)
                accuracies[model_name] = accuracy_score(y_test, y_pred)

            # Find the best model
            if accuracies:
                best_model = max(accuracies, key=accuracies.get)
                model_info = get_model_info(best_model)
                plot = plot_model_performance(y_test, y_pred, problem_type)
                return render_template('result.html', accuracies=accuracies, best_model=best_model, model_info=model_info, plot=plot, problem_type=problem_type)
            else:
                return "No models were successfully trained for classification."

        elif problem_type == 'regression':
            models = {
                'Linear Regression': LinearRegression(),
                'Support Vector Machine': SVR(),
                'K-Nearest Neighbors': KNeighborsRegressor(),
                'Decision Tree': DecisionTreeRegressor()
            }
            # Train models and calculate mean squared error
            errors = {}
            for model_name, model in models.items():
                pipeline = Pipeline(steps=[('preprocessor', preprocessor), ('regressor', model)])
                X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

                pipeline.fit(X_train, y_train)
                y_pred = pipeline.predict(X_test)
                errors[model_name] = mean_squared_error(y_test, y_pred)

            # Find the best model
            if errors:
                best_model = min(errors, key=errors.get)
                model_info = get_model_info(best_model)
                plot = plot_model_performance(y_test, y_pred, problem_type)
                return render_template('result.html', errors=errors, best_model=best_model, model_info=model_info, plot=plot, problem_type=problem_type)
            else:
                return "No models were successfully trained for regression."

    except pd.errors.EmptyDataError:
        return 'No data in the file'
    except pd.errors.ParserError:
        return 'Error parsing file. Please upload a valid CSV file'
    except Exception as e:
        return f"Error processing dataset: {str(e)}"

def get_model_info(model_name):
    # Define model descriptions (replace with actual descriptions as needed)
    model_descriptions = {
        'Random Forest': 'Random Forest is an ensemble learning method for classification and regression that operates by constructing a multitude of decision trees at training time and outputting the class that is the mode of the classes (classification) or mean prediction (regression) of the individual trees.',
        'Logistic Regression': 'Logistic Regression is a statistical model that uses a logistic function to model a binary dependent variable, although it can be extended to model more outcomes.',
        'Support Vector Machine': 'Support Vector Machine (SVM) is a supervised machine learning algorithm that can be used for classification or regression tasks. It finds an optimal hyperplane that categorizes the data into different classes.',
        'K-Nearest Neighbors': 'K-Nearest Neighbors (KNN) is a non-parametric, lazy learning algorithm that stores all available cases and classifies new cases based on a similarity measure (e.g., distance functions).',
        'Gradient Boosting': 'Gradient Boosting is a machine learning technique for regression and classification problems, which produces a prediction model in the form of an ensemble of weak prediction models, typically decision trees.',
        'Naive Bayes': 'Naive Bayes classifiers are a family of simple "probabilistic classifiers" based on applying Bayes\' theorem with strong independence assumptions between the features.',
        'Decision Tree': 'Decision Tree is a flowchart-like structure in which each internal node represents a "test" on an attribute, each branch represents the outcome of the test, and each leaf node represents a class label.',
        'Linear Regression': 'Linear Regression is a linear approach to modeling the relationship between a scalar response (dependent variable) and one or more explanatory variables (independent variables).',
        'SVR': 'Support Vector Regression (SVR) is a type of SVM algorithm that uses the principles of Support Vector Machines for regression analysis.',
        'KNeighborsRegressor': 'K-Nearest Neighbors Regression (KNN Regression) is a non-parametric method used for predicting continuous values. It predicts the value of an input data point based on the average of the values of its k nearest neighbors.',
        'DecisionTreeRegressor': 'Decision Tree Regression uses a decision tree as a predictive model that maps features to target values, and it breaks down a dataset into smaller and smaller subsets while at the same time an associated decision tree is incrementally developed.'
    }
    return model_descriptions.get(model_name, 'No description available.')

def plot_model_performance(y_true, y_pred, problem_type):
    if problem_type == 'classification':
        # Plot confusion matrix for classification
        plt.figure(figsize=(8, 6))
        sns.heatmap(pd.crosstab(y_true, y_pred, rownames=['Actual'], colnames=['Predicted']), annot=True, cmap='Blues', fmt='d')
        plt.title('Confusion Matrix')
        plt.tight_layout()
    elif problem_type == 'regression':
        # Plot scatter plot for regression
        plt.figure(figsize=(8, 6))
        plt.scatter(y_true, y_pred, color='blue')
        plt.plot([min(y_true), max(y_true)], [min(y_true), max(y_true)], linestyle='--', color='red')
        plt.xlabel('Actual')
        plt.ylabel('Predicted')
        plt.title('Actual vs Predicted')
        plt.tight_layout()

    # Convert plot to base64 for embedding in HTML
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plot_base64 = base64.b64encode(buf.read()).decode('utf-8').replace('\n', '')
    plt.close()

    return plot_base64

if __name__ == '__main__':
    app.run(debug=True)
