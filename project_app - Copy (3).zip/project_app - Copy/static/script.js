document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    const fileInput = document.querySelector('input[type=file]');
    const submitButton = document.querySelector('input[type=submit]');

    // Disable submit button initially
    submitButton.disabled = true;

    // Add event listener to file input for validation
    fileInput.addEventListener('change', function() {
        const file = fileInput.files[0];
        if (file) {
            const fileSize = file.size / 1024 / 1024; // in MB
            const fileType = file.type; // MIME type

            // Example validation: Accept only CSV files under 5MB
            if (fileType !== 'text/csv') {
                alert('Please upload a CSV file.');
                fileInput.value = ''; // Reset file input
                submitButton.disabled = true;
            } else if (fileSize > 5) {
                alert('File size exceeds 5MB. Please upload a smaller file.');
                fileInput.value = ''; // Reset file input
                submitButton.disabled = true;
            } else {
                submitButton.disabled = false;
            }
        } else {
            submitButton.disabled = true;
        }
    });

    // Optional: Add more custom JavaScript functionalities as needed
});
