from flask import Flask, request, render_template
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from joblib import load

app = Flask(__name__)

# Load the trained model and label encoder
model = load('saved_models/recommender_model.joblib')
label_encoder = load('saved_models/label_encoder.joblib')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/recommend', methods=['POST'])
def recommend():
    file = request.files['dataset']
    if file:
        try:
            # Load the uploaded dataset
            df = pd.read_csv(file)
            
            # Assuming the last column is the target
            target_column = df.columns[-1]
            X = df.drop(target_column, axis=1)
            y = df[target_column]

            # Extract dataset characteristics
            dataset_characteristics = {
                'num_samples': len(df),
                'num_features': len(df.columns) - 1,
                'num_classes': len(y.unique())
            }

            # Create a DataFrame for prediction
            input_df = pd.DataFrame([dataset_characteristics])

            # Predict the most suitable algorithm
            prediction = model.predict(input_df)
            recommended_algorithm = label_encoder.inverse_transform(prediction)[0]

            return render_template('index.html', recommendation=recommended_algorithm)

        except Exception as e:
            return f"Error processing dataset: {str(e)}"

    return 'Please upload a valid dataset'

if __name__ == '__main__':
    app.run(debug=True)